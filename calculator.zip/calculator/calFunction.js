let display = document.getElementById('calculation');
let buttons = document.querySelectorAll('button');

let buttonArray = Array.from(buttons);
let answer = '';

buttonArray.forEach(btn =>{
	btn.addEventListener('click',(e) =>{

		console.log(e.target.innerHTML);
		if(e.target.innerHTML == 'DEL'){
			answer = answer.substring(0, answer.length-1);
			display.value = answer;
		}else if(e.target.innerHTML == 'AC'){
			answer = '';
			display.value = answer;
		}else if (e.target.innerHTML == '='){
			answer = eval(answer);
			display.value = answer;
 		}else{
 			answer += e.target.innerHTML;
 			display.value = answer;
 		}


	});
});